#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./USMART/usmart.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/DS18B20/ds18b20.h"
#include "./BSP/DS18B20/HX711.h"
#include "./BSP/BEEP/beep.h"

//float WeightData;
unsigned long WeightData;
#define TEMP_MAX_VALUE 300 // ���ֵ��ֵ30
#define WEIG_MAX_VALUE 1429 //14.29g

int main(void)
{
    uint8_t t = 0;
    short temperature;

    HAL_Init();                         
    sys_stm32_clock_init(RCC_PLL_MUL9); /* ����ʱ��, 72Mhz */
    delay_init(72);                     /* ��ʱ��ʼ�� */
    usart_init(115200);                 /* ���ڳ�ʼ��Ϊ115200 */
    led_init();                         
    lcd_init();                         
	  beep_init();                        

		lcd_show_string(30, 50, 200, 16, 16, "Platform: STM32", RED);
    lcd_show_string(30, 70, 200, 16, 16, "Dust Explosion TEST", RED);//DS18B20 Test
    lcd_show_string(30, 90, 200, 16, 16, "Point 1", RED);

    while (ds18b20_init()) /* DS18B20��ʼ�� */
    {
        lcd_show_string(30, 110, 200, 16, 16, "DS18B20 Error", RED);
        delay_ms(200);
        lcd_fill(30, 110, 239, 130 + 16, WHITE);
        delay_ms(200);
    }

    lcd_show_string(30, 110, 200, 16, 16, "TEST OK", RED);
    lcd_show_string(30, 130, 200, 16, 16, "Temp:   . C", BLUE);
    lcd_show_string(30, 150, 200, 16, 16, "Weight:   .  g", BLUE);
		
    InitWeight();

    while (1)
    {
        if (t % 10 == 0) /* ÿ100ms��ȡһ�� */
        {
            temperature = ds18b20_get_temperature();

            if (temperature < 0)
            {
                lcd_show_char(30 + 40, 130, '-', 16, 0, BLUE); /* ��ʾ���� */
                temperature = -temperature;                    /* תΪ���� */
            }
            else
            {
                lcd_show_char(30 + 40, 130, ' ', 16, 0, BLUE); /* ȥ������ */
            }

            lcd_show_num(30 + 40 + 8, 130, temperature / 10, 2, 16, BLUE);  /* ��ʾ�������� 8 16 24*/
            lcd_show_num(30 + 40 + 32, 130, temperature % 10, 1, 16, BLUE); /* ��ʾС������ */
            
            
            WeightData = Get_Weight();
            lcd_show_num(30 + 40 + 16, 150, WeightData / 100, 2, 16, BLUE);
						lcd_show_num(30 + 40 + 48, 150, WeightData % 100, 2, 16, BLUE);
						
						//lcd_show_num(30 + 40 + 48, 130, WeightData, 6, 16, BLUE);
            //lcd_show_num(30 + 40 + 48, 130, WeightData / 100, 3, 16, BLUE);
						//lcd_show_num(30 + 40 + 60, 130, WeightData % 100, 2, 16, BLUE);
            if(temperature > TEMP_MAX_VALUE ||WeightData > WEIG_MAX_VALUE)
            {
                BEEP(1);
                lcd_show_string(30, 170, 200, 16, 16, "Warning: Dangerous!", RED);
            }
            else
            {
                BEEP(0);
                lcd_show_string(30, 170, 200, 16, 16, "                     ", RED);
            }
        }

        delay_ms(10);
        t++;

        if (t == 20)
        {
            t = 0;
            //LED0_TOGGLE(); /* LED0��˸ */
        }
    }
}
