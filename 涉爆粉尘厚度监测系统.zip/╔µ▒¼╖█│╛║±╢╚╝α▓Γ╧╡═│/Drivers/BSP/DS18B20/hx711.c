//#include "stm32f10x.h"
#include "HX711.h"

unsigned long Weight_Maopi;


void SetHx711OutIn(unsigned char PinStatus)
{
/*    GPIO_InitTypeDef GPIO_InitST;
    if(PinStatus == 0)
    {
        GPIO_InitST.GPIO_Mode=GPIO_Mode_Out_PP;
    }
    else
    {
        GPIO_InitST.GPIO_Mode=GPIO_Mode_IPU;
    }
    GPIO_InitST.GPIO_Pin=HX711_DOUT_PIN;
	GPIO_InitST.GPIO_Speed=GPIO_Speed_10MHz;
	GPIO_Init(HX711_PORT,&GPIO_InitST);
*/    
    GPIO_InitTypeDef gpio_init_struct;
   
    //DS18B20_DQ_GPIO_CLK_ENABLE();   /* ����DQ����ʱ�� */
    
    if(PinStatus == 0)
    {
        //GPIO_InitST.GPIO_Mode=GPIO_Mode_Out_PP;
        gpio_init_struct.Mode = GPIO_MODE_OUTPUT_PP;            /* ��©��� */
    }
    else
    {
        //GPIO_InitST.GPIO_Mode=GPIO_Mode_IPU;
        gpio_init_struct.Mode = GPIO_MODE_INPUT;            /* ��©��� */
    }

    gpio_init_struct.Pin = HX711_DOUT_PIN;
    //gpio_init_struct.Mode = GPIO_MODE_OUTPUT_OD;            /* ��©��� */
    gpio_init_struct.Pull = GPIO_PULLUP;                    /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;          /* ���� */
    HAL_GPIO_Init(HX711_PORT, &gpio_init_struct);
    
}

//****************************************************
//��ʱ����
//****************************************************
void Delay__hx711_us(void)
{
	unsigned char i=10000;
    while(i--);
}

//****************************************************
//��ȡHX711
//****************************************************
unsigned long HX711_Read(void)	//����128
{
	unsigned long count; 
	unsigned char i; 
    SetHx711OutIn(0);
    Delay__hx711_us();
  	HX711_DOUT(1); 
	Delay__hx711_us();
  	HX711_SCK(0); 
  	count=0;
    SetHx711OutIn(1);
    Delay__hx711_us();    
  	while(HX711_DOUT_IN); 
  	for(i=0;i<24;i++)
	{ 
	  	HX711_SCK(1); 
	  	count=count<<1; 
		HX711_SCK(0); 
	  	if(HX711_DOUT_IN)
			count++; 
	} 
	//EA = 1;
 	HX711_SCK(1); 
    count=count^0x800000;//��25�������½�����ʱ��ת������
	Delay__hx711_us();
	HX711_SCK(0);  
	return(count);
}

//****************************************************
//����
//****************************************************

//float Get_Weight(void)
unsigned long Get_Weight(void)
{
	//float Weight_Shiwu;
	long Weight_Shiwu;

	Weight_Shiwu = HX711_Read();
	/*SendSci(0xff);
	SendSci(0xff);
	SendSci(Weight_Shiwu>>24);
	SendSci(Weight_Shiwu>>16);
	SendSci(Weight_Shiwu>>8);
	SendSci(Weight_Shiwu);*/
	Weight_Shiwu = Weight_Shiwu - Weight_Maopi;		//��ȡ����
	if(Weight_Shiwu > 0)			
	{	
		Weight_Shiwu = (unsigned int)((float)Weight_Shiwu/GapValue *100); 
		//Weight_Shiwu = (unsigned int)((float)Weight_Shiwu/GapValue *100); 	//����ʵ���ʵ������
		//Weight_Shiwu = (float)((float)Weight_Shiwu/GapValue * 10);
		//if(Weight_Shiwu > 300) //real number,*100 because need float 
		if(Weight_Shiwu > 30000)
		{
			return 0xFFFF;
		}
	}
	else
	{
		return 0x0000;
	}
	return Weight_Shiwu;
}

//****************************************************
//��ȡëƤ����
//****************************************************
void InitWeight(void)
{
  
    GPIO_InitTypeDef gpio_init_struct;
   
    __HAL_RCC_GPIOA_CLK_ENABLE();;   /* ����DQ����ʱ�� */
    

    gpio_init_struct.Mode = GPIO_MODE_OUTPUT_OD;            /* ��©��� */

    gpio_init_struct.Pin = HX711_DOUT_PIN|HX711_SCK_PIN;
    //gpio_init_struct.Mode = GPIO_MODE_OUTPUT_OD;            /* ��©��� */
    gpio_init_struct.Pull = GPIO_PULLUP;                    /* ���� */
    gpio_init_struct.Speed = GPIO_SPEED_FREQ_HIGH;          /* ���� */
    HAL_GPIO_Init(HX711_PORT, &gpio_init_struct);
    
    Weight_Maopi = HX711_Read();	
}


